package com.fishvoice.app.xposed;

import android.media.AudioRecord;
import android.os.SystemClock;

import com.fishvoice.app.dsp.StreamProcessor;
import com.fishvoice.app.dsp.VoiceParams;

import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Модуль LSPosed. Встраивается в выбранные приложения и подменяет данные,
 * которые они читают из микрофона через AudioRecord.read(...).
 * Приложение при этом получает уже изменённый голос (голосовые, звонки и т.д.).
 */
public class VoiceHook implements IXposedHookLoadPackage {
    private static final String MODULE_PKG = "com.fishvoice.app";
    private static final String PREFS = "fish_voice_prefs";

    private static final int SHORTS = 0, FLOATS = 1, BYTES = 2, BUFFER = 3;

    private static final Map<AudioRecord, StreamProcessor> PROCS =
            Collections.synchronizedMap(new WeakHashMap<AudioRecord, StreamProcessor>());
    private static final ThreadLocal<Boolean> BUSY = new ThreadLocal<Boolean>();

    private static XSharedPreferences xprefs;
    private static long lastLoad = -10000;
    private static volatile VoiceParams current;
    private static int errors = 0;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) throws Throwable {
        if (MODULE_PKG.equals(lp.packageName)) {
            // Чтобы приложение могло показать "модуль активен"
            try {
                XposedHelpers.findAndHookMethod(MODULE_PKG + ".FishApp", lp.classLoader,
                        "isModuleActive", XC_MethodReplacement.returnConstant(Boolean.TRUE));
            } catch (Throwable t) {
                XposedBridge.log("fish.voice: self hook failed: " + t);
            }
            return;
        }
        if ("android".equals(lp.packageName)) return;

        hook(byte[].class, int.class, int.class, int.class, new Reader(BYTES));
        hook(byte[].class, int.class, int.class, new Reader(BYTES));
        hook(short[].class, int.class, int.class, int.class, new Reader(SHORTS));
        hook(short[].class, int.class, int.class, new Reader(SHORTS));
        hook(float[].class, int.class, int.class, int.class, new Reader(FLOATS));
        hook(ByteBuffer.class, int.class, int.class, new Reader(BUFFER));
        hook(ByteBuffer.class, int.class, new Reader(BUFFER));
    }

    private static void hook(Object... typesAndCallback) {
        try {
            XposedHelpers.findAndHookMethod(AudioRecord.class, "read", typesAndCallback);
        } catch (Throwable t) {
            XposedBridge.log("fish.voice: hook failed: " + t);
        }
    }

    /** Текущие настройки или null, если обработка выключена. Перечитывает файл раз в ~0.4 с. */
    private static VoiceParams params() {
        long now = SystemClock.elapsedRealtime();
        if (now - lastLoad > 400) {
            lastLoad = now;
            try {
                if (xprefs == null) xprefs = new XSharedPreferences(MODULE_PKG, PREFS);
                xprefs.reload();
                if (xprefs.getBoolean(VoiceParams.K_ENABLED, false)) {
                    current = VoiceParams.fromPrefs(xprefs);
                } else {
                    current = null;
                }
            } catch (Throwable t) {
                current = null;
            }
        }
        return current;
    }

    private static final class Reader extends XC_MethodHook {
        private final int kind;

        Reader(int kind) {
            this.kind = kind;
        }

        @Override
        protected void beforeHookedMethod(MethodHookParam param) {
            // Внутренние перегрузки вызывают друг друга: обрабатываем только самый внешний вызов
            if (Boolean.TRUE.equals(BUSY.get())) {
                param.setObjectExtra("fv_skip", Boolean.TRUE);
            } else {
                BUSY.set(Boolean.TRUE);
            }
        }

        @Override
        protected void afterHookedMethod(MethodHookParam param) {
            if (param.getObjectExtra("fv_skip") != null) return;
            BUSY.set(Boolean.FALSE);
            if (param.hasThrowable()) return;
            try {
                Object r = param.getResult();
                if (!(r instanceof Integer)) return;
                int n = (Integer) r;
                if (n <= 0) return;

                VoiceParams p = params();
                if (p == null) return;

                AudioRecord rec = (AudioRecord) param.thisObject;
                StreamProcessor sp = PROCS.get(rec);
                if (sp == null) {
                    sp = new StreamProcessor(rec.getSampleRate(), rec.getChannelCount());
                    PROCS.put(rec, sp);
                }
                switch (kind) {
                    case SHORTS:
                        sp.shorts((short[]) param.args[0], (Integer) param.args[1], n, p);
                        break;
                    case FLOATS:
                        sp.floats((float[]) param.args[0], (Integer) param.args[1], n, p);
                        break;
                    case BYTES:
                        sp.bytes((byte[]) param.args[0], (Integer) param.args[1], n, rec.getAudioFormat(), p);
                        break;
                    default:
                        sp.buffer((ByteBuffer) param.args[0], n, rec.getAudioFormat(), p);
                        break;
                }
            } catch (Throwable t) {
                if (errors++ < 5) XposedBridge.log("fish.voice: process error: " + t);
            }
        }
    }
}
