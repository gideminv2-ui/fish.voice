package com.fishvoice.app.dsp;

/**
 * Обработка одного моно-канала в реальном времени.
 * Цепочка: сдвиг высоты (две линии задержки с плавным переключением) -> тембр ->
 * робот (кольцевая модуляция) -> искажение -> эхо -> громкость -> мягкий лимитер.
 * Задержка около 17 мс.
 */
public final class VoiceEngine {
    private static final double TWO_PI = Math.PI * 2.0;

    private final float window;
    private final float[] buf;
    private final int mask;
    private int writePos;
    private float phase;

    private float lp;
    private final float lpCoef;

    private double roboPhase;
    private final double roboStep;

    private final float[] echoBuf;
    private int echoPos;

    public VoiceEngine(int sampleRate) {
        int rate = Math.max(8000, sampleRate);
        window = rate * 0.035f;
        int size = 256;
        while (size < (int) (window * 2f) + 16) size <<= 1;
        buf = new float[size];
        mask = size - 1;
        lpCoef = (float) (1.0 - Math.exp(-TWO_PI * 1500.0 / rate));
        roboStep = TWO_PI * 55.0 / rate;
        echoBuf = new float[(int) (rate * 0.26f)];
    }

    private float tap(float d) {
        int id = (int) d;
        float frac = d - id;
        int i0 = (writePos - id) & mask;
        int i1 = (i0 - 1) & mask;
        return buf[i0] * (1f - frac) + buf[i1] * frac;
    }

    /** Обрабатывает x[off .. off+len) на месте. Значения -1..1. */
    public void process(float[] x, int off, int len, VoiceParams p) {
        if (p == null || p.isNeutral()) return;

        final boolean shift = Math.abs(p.pitch) > 0.02f;
        final float ratio = (float) Math.pow(2.0, p.pitch / 12.0);
        final float dphase = (1f - ratio) / window;
        final boolean tone = Math.abs(p.timbre) > 0.01f;
        final float lowG = 1f - 0.5f * p.timbre;
        final float highG = 1f + p.timbre;
        final boolean robot = p.robot > 0.01f;
        final boolean dist = p.distortion > 0.01f;
        final float drive = 1f + 10f * p.distortion;
        final boolean echo = p.echo > 0.01f;
        final float gain = p.gain;

        for (int i = 0; i < len; i++) {
            float s = x[off + i];
            buf[writePos] = s;

            if (shift) {
                float d1 = 1f + phase * window;
                float ph2 = phase + 0.5f;
                if (ph2 >= 1f) ph2 -= 1f;
                float d2 = 1f + ph2 * window;
                float sn = (float) Math.sin(Math.PI * phase);
                float g1 = sn * sn;
                s = g1 * tap(d1) + (1f - g1) * tap(d2);
                phase += dphase;
                if (phase >= 1f) phase -= 1f;
                else if (phase < 0f) phase += 1f;
            }
            writePos = (writePos + 1) & mask;

            if (tone) {
                lp += lpCoef * (s - lp);
                float high = s - lp;
                s = lp * lowG + high * highG;
            }

            if (robot) {
                float mod = (float) Math.sin(roboPhase);
                roboPhase += roboStep;
                if (roboPhase > TWO_PI) roboPhase -= TWO_PI;
                s = s * (1f - p.robot) + s * mod * p.robot;
            }

            if (dist) {
                float wet = (float) Math.tanh(s * drive) * 0.8f;
                s = s * (1f - p.distortion) + wet * p.distortion;
            }

            if (echo) {
                float e = echoBuf[echoPos];
                echoBuf[echoPos] = s + e * 0.45f;
                s += e * p.echo;
            } else {
                echoBuf[echoPos] = 0f;
            }
            if (++echoPos >= echoBuf.length) echoPos = 0;

            s *= gain;

            float a = Math.abs(s);
            if (a > 0.85f) {
                float over = (a - 0.85f) / 0.15f;
                a = 0.85f + 0.15f * (float) Math.tanh(over);
                s = s < 0 ? -a : a;
            }
            x[off + i] = s;
        }
    }
}
