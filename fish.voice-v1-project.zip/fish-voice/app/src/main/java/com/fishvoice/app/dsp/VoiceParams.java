package com.fishvoice.app.dsp;

import android.content.SharedPreferences;

/** Неизменяемый набор настроек голоса. Общий для приложения и для хука. */
public final class VoiceParams {
    public static final String K_ENABLED = "enabled";
    public static final String K_PITCH = "pitch";
    public static final String K_TIMBRE = "timbre";
    public static final String K_ROBOT = "robot";
    public static final String K_ECHO = "echo";
    public static final String K_DIST = "dist";
    public static final String K_GAIN = "gain";

    public final float pitch;       // полутоны, -12..+12
    public final float timbre;      // -1 (глухой) .. +1 (звонкий)
    public final float robot;       // 0..1
    public final float echo;        // 0..1
    public final float distortion;  // 0..1
    public final float gain;        // 0.5..2

    public VoiceParams(float pitch, float timbre, float robot, float echo, float distortion, float gain) {
        this.pitch = clamp(pitch, -24f, 24f);
        this.timbre = clamp(timbre, -1f, 1f);
        this.robot = clamp(robot, 0f, 1f);
        this.echo = clamp(echo, 0f, 1f);
        this.distortion = clamp(distortion, 0f, 1f);
        this.gain = clamp(gain, 0f, 4f);
    }

    private static float clamp(float v, float lo, float hi) {
        if (Float.isNaN(v)) return lo > 0 ? lo : 0f;
        return v < lo ? lo : (v > hi ? hi : v);
    }

    public static VoiceParams neutral() {
        return new VoiceParams(0, 0, 0, 0, 0, 1f);
    }

    public boolean isNeutral() {
        return Math.abs(pitch) < 0.02f && Math.abs(timbre) < 0.01f && robot < 0.01f
                && echo < 0.01f && distortion < 0.01f && Math.abs(gain - 1f) < 0.01f;
    }

    /** Читает настройки (работает и с XSharedPreferences). */
    public static VoiceParams fromPrefs(SharedPreferences sp) {
        return new VoiceParams(
                sp.getFloat(K_PITCH, 0f),
                sp.getFloat(K_TIMBRE, 0f),
                sp.getFloat(K_ROBOT, 0f),
                sp.getFloat(K_ECHO, 0f),
                sp.getFloat(K_DIST, 0f),
                sp.getFloat(K_GAIN, 1f));
    }

    public void saveTo(SharedPreferences.Editor e) {
        e.putFloat(K_PITCH, pitch);
        e.putFloat(K_TIMBRE, timbre);
        e.putFloat(K_ROBOT, robot);
        e.putFloat(K_ECHO, echo);
        e.putFloat(K_DIST, distortion);
        e.putFloat(K_GAIN, gain);
    }
}
