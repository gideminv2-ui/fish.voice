package com.fishvoice.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.fishvoice.app.dsp.VoiceParams;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Вся панель управления. Используется и в окне приложения, и в плавающем окне. */
public class PanelView extends LinearLayout {

    public interface Host {
        void openOverlay();
        void toggleMonitor();
        boolean isMonitoring();
    }

    private final Store store;
    private final boolean compact;
    private Host host;

    private LinearLayout startCard;
    private TextView startBtn, startSub, statusChip, monitorBtn;
    private View helpCard;
    private FlowLayout chipLayout;
    private final Map<String, TextView> chipViews = new LinkedHashMap<String, TextView>();
    private final List<Slider> sliders = new ArrayList<Slider>();
    private boolean updating, selfChange;
    private int builtCustomsVersion = -1;

    private final Runnable listener = new Runnable() {
        @Override public void run() { syncAll(); }
    };

    public PanelView(Context c, boolean compact) {
        super(c);
        this.compact = compact;
        this.store = Store.get(c);
        setOrientation(VERTICAL);
        build();
        syncAll();
    }

    public void setHost(Host h) { host = h; }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        store.addListener(listener);
        syncAll();
    }

    @Override
    protected void onDetachedFromWindow() {
        store.removeListener(listener);
        super.onDetachedFromWindow();
    }

    public void refreshMonitorButton() {
        if (monitorBtn == null) return;
        boolean on = host != null && host.isMonitoring();
        monitorBtn.setText(on ? "⏹ Остановить прослушивание" : "🎧 Прослушать себя");
    }

    // ---------------------------------------------------------------- построение

    private LinearLayout.LayoutParams lp(int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        p.topMargin = Ui.dp(getContext(), topDp);
        return p;
    }

    private TextView sectionLabel(String s) {
        TextView t = Ui.text(getContext(), s, 11, Ui.MUTED, true);
        t.setLetterSpacing(0.12f);
        return t;
    }

    private TextView button(String text, OnClickListener l) {
        Context c = getContext();
        TextView t = Ui.text(c, text, 13, Ui.TEXT, false);
        t.setPadding(Ui.dp(c, 14), Ui.dp(c, 10), Ui.dp(c, 14), Ui.dp(c, 10));
        t.setBackground(Ui.ripple(c, Ui.stroked(c, Ui.SURFACE, Ui.STROKE, 1, 14), 14));
        t.setOnClickListener(l);
        return t;
    }

    private void build() {
        final Context c = getContext();

        if (!compact) {
            LinearLayout head = new LinearLayout(c);
            head.setGravity(Gravity.CENTER_VERTICAL);
            head.addView(Ui.text(c, "🐟 fish.voice", 26, Ui.TEXT, true));
            TextView ver = Ui.text(c, "v1", 11, Ui.BG1, true);
            ver.setBackground(Ui.rect(c, Ui.ACCENT, 8));
            ver.setPadding(Ui.dp(c, 7), Ui.dp(c, 2), Ui.dp(c, 7), Ui.dp(c, 2));
            LinearLayout.LayoutParams vl = new LinearLayout.LayoutParams(
                    LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
            vl.leftMargin = Ui.dp(c, 8);
            head.addView(ver, vl);
            addView(head, lp(0));
        }

        statusChip = Ui.text(c, "", 12, Ui.MUTED, true);
        statusChip.setPadding(Ui.dp(c, 12), Ui.dp(c, 6), Ui.dp(c, 12), Ui.dp(c, 6));
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        sl.topMargin = Ui.dp(c, compact ? 0 : 10);
        addView(statusChip, sl);

        // Большая кнопка СТАРТ / СТОП
        startCard = new LinearLayout(c);
        startCard.setOrientation(VERTICAL);
        startCard.setGravity(Gravity.CENTER);
        startCard.setPadding(Ui.dp(c, 16), Ui.dp(c, compact ? 14 : 22), Ui.dp(c, 16), Ui.dp(c, compact ? 14 : 22));
        startBtn = Ui.text(c, "", compact ? 20 : 28, Ui.BG1, true);
        startBtn.setLetterSpacing(0.08f);
        startSub = Ui.text(c, "", 12, Ui.BG1, false);
        startSub.setGravity(Gravity.CENTER);
        startCard.addView(startBtn);
        startCard.addView(startSub);
        startCard.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) { store.setEnabled(!store.isEnabled()); }
        });
        addView(startCard, lp(compact ? 8 : 14));

        // Голоса
        addView(sectionLabel("ГОЛОС"), lp(compact ? 14 : 20));
        chipLayout = new FlowLayout(c, Ui.dp(c, 8), Ui.dp(c, 8));
        addView(chipLayout, lp(8));

        // Настройки голоса
        addView(sectionLabel("НАСТРОЙКИ ГОЛОСА"), lp(compact ? 14 : 20));
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(VERTICAL);
        card.setPadding(Ui.dp(c, 14), Ui.dp(c, 10), Ui.dp(c, 14), Ui.dp(c, 12));
        card.setBackground(Ui.rect(c, Ui.SURFACE, 18));
        sliders.add(new Slider(card, "Высота тона (полутоны)", -12f, 12f, 0));
        sliders.add(new Slider(card, "Тембр: глухой ↔ звонкий", -1f, 1f, 3));
        sliders.add(new Slider(card, "Робот", 0f, 1f, 1));
        sliders.add(new Slider(card, "Эхо", 0f, 1f, 1));
        sliders.add(new Slider(card, "Искажение", 0f, 1f, 1));
        sliders.add(new Slider(card, "Громкость", 0.5f, 2f, 2));
        addView(card, lp(8));

        if (!compact) {
            FlowLayout actions = new FlowLayout(c, Ui.dp(c, 8), Ui.dp(c, 8));
            actions.addView(button("💾 Сохранить мой голос", new OnClickListener() {
                @Override public void onClick(View v) { showSaveDialog(); }
            }));
            monitorBtn = button("🎧 Прослушать себя", new OnClickListener() {
                @Override public void onClick(View v) { if (host != null) host.toggleMonitor(); }
            });
            actions.addView(monitorBtn);
            actions.addView(button("🪟 Плавающее окно", new OnClickListener() {
                @Override public void onClick(View v) { if (host != null) host.openOverlay(); }
            }));
            addView(actions, lp(16));

            LinearLayout help = new LinearLayout(c);
            help.setOrientation(VERTICAL);
            help.setPadding(Ui.dp(c, 16), Ui.dp(c, 14), Ui.dp(c, 16), Ui.dp(c, 14));
            help.setBackground(Ui.stroked(c, 0x22FF5C7A, 0x66FF5C7A, 1, 18));
            help.addView(Ui.text(c, "Как включить в Telegram и других приложениях", 14, Ui.TEXT, true));
            TextView body = Ui.text(c,
                    "Android не даёт обычному приложению подменять микрофон других программ, "
                    + "поэтому fish.voice работает как модуль LSPosed: он встраивается в выбранные "
                    + "приложения и меняет звук с микрофона на лету.\n\n"
                    + "1. Нужны root (Magisk) и LSPosed.\n"
                    + "2. LSPosed → Модули → fish.voice v1 → включить.\n"
                    + "3. Выбрать приложения: Telegram и другие.\n"
                    + "4. Принудительно остановить Telegram и открыть заново.\n"
                    + "5. Здесь нажать СТАРТ.\n\n"
                    + "В звонках используй наушники, иначе собеседник может слышать эхо.",
                    13, Ui.MUTED, false);
            body.setLineSpacing(0f, 1.15f);
            LinearLayout.LayoutParams bl = lp(8);
            help.addView(body, bl);
            helpCard = help;
            addView(help, lp(16));
        }
    }

    // ---------------------------------------------------------------- голоса

    private void rebuildChips() {
        chipLayout.removeAllViews();
        chipViews.clear();
        for (VoicePreset p : VoicePreset.builtins()) addChip(p.name, p.emoji, p, false);
        for (VoicePreset p : store.getCustoms()) addChip(p.name, p.emoji, p, true);
        addChip(Store.CUSTOM_NAME, "🎛", null, false);
    }

    private void addChip(final String name, String emoji, final VoicePreset preset, boolean deletable) {
        Context c = getContext();
        TextView t = Ui.text(c, emoji + " " + name, 14, Ui.TEXT, false);
        t.setPadding(Ui.dp(c, 14), Ui.dp(c, 9), Ui.dp(c, 14), Ui.dp(c, 9));
        t.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) {
                store.setVoice(name, preset != null ? preset.params : store.getParams());
            }
        });
        if (deletable && !compact) {
            t.setOnLongClickListener(new OnLongClickListener() {
                @Override public boolean onLongClick(View v) { confirmDelete(name); return true; }
            });
        }
        chipViews.put(name, t);
        chipLayout.addView(t);
    }

    private void syncChips() {
        Context c = getContext();
        String cur = store.getPreset();
        for (Map.Entry<String, TextView> e : chipViews.entrySet()) {
            TextView t = e.getValue();
            boolean sel = e.getKey().equals(cur);
            if (sel) {
                t.setBackground(Ui.ripple(c, Ui.grad(c, Ui.ACCENT, Ui.ACCENT2,
                        GradientDrawable.Orientation.LEFT_RIGHT, 18), 18));
                t.setTextColor(Ui.BG1);
                t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            } else {
                t.setBackground(Ui.ripple(c, Ui.stroked(c, Ui.SURFACE, Ui.STROKE, 1, 18), 18));
                t.setTextColor(Ui.TEXT);
                t.setTypeface(android.graphics.Typeface.DEFAULT);
            }
        }
    }

    private void syncStart() {
        Context c = getContext();
        boolean on = store.isEnabled();
        boolean active = FishApp.isModuleActive();
        startBtn.setText(on ? "⏹  СТОП" : "▶  СТАРТ");
        startBtn.setTextColor(on ? Ui.TEXT : Ui.BG1);
        if (on) {
            startCard.setBackground(Ui.ripple(c, Ui.stroked(c, Ui.SURFACE, Ui.OK, 2, 22), 22));
            startSub.setText(active ? "Голос меняется в реальном времени"
                    : "Включено, но модуль LSPosed не активен");
            startSub.setTextColor(active ? Ui.OK : Ui.DANGER);
        } else {
            startCard.setBackground(Ui.ripple(c, Ui.grad(c, Ui.ACCENT, Ui.ACCENT2,
                    GradientDrawable.Orientation.LEFT_RIGHT, 22), 22));
            startSub.setText("Нажми, чтобы менять голос");
            startSub.setTextColor(Ui.BG1);
        }
    }

    private void syncStatus() {
        Context c = getContext();
        boolean act = FishApp.isModuleActive();
        statusChip.setText(act ? "●  LSPosed: модуль активен" : "○  LSPosed: не активен (нужен root)");
        statusChip.setTextColor(act ? Ui.OK : Ui.DANGER);
        statusChip.setBackground(Ui.rect(c, act ? 0x2235E08A : 0x22FF5C7A, 12));
        if (helpCard != null) helpCard.setVisibility(act ? GONE : VISIBLE);
    }

    private void syncAll() {
        if (builtCustomsVersion != store.customsVersion() || chipViews.isEmpty()) {
            rebuildChips();
            builtCustomsVersion = store.customsVersion();
        }
        syncChips();
        syncStart();
        syncStatus();
        if (!selfChange) {
            updating = true;
            VoiceParams p = store.getParams();
            sliders.get(0).set(p.pitch);
            sliders.get(1).set(p.timbre);
            sliders.get(2).set(p.robot);
            sliders.get(3).set(p.echo);
            sliders.get(4).set(p.distortion);
            sliders.get(5).set(p.gain);
            updating = false;
        }
    }

    private void onSliderChanged() {
        VoiceParams p = new VoiceParams(sliders.get(0).value(), sliders.get(1).value(),
                sliders.get(2).value(), sliders.get(3).value(), sliders.get(4).value(),
                sliders.get(5).value());
        selfChange = true;
        store.setVoice(Store.CUSTOM_NAME, p);
        selfChange = false;
    }

    // ---------------------------------------------------------------- диалоги

    private void showSaveDialog() {
        final Context c = getContext();
        final EditText et = new EditText(c);
        et.setHint("Название голоса");
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT);
        FrameLayout wrap = new FrameLayout(c);
        wrap.setPadding(Ui.dp(c, 20), Ui.dp(c, 8), Ui.dp(c, 20), 0);
        wrap.addView(et);
        new AlertDialog.Builder(c)
                .setTitle("Сохранить мой голос")
                .setView(wrap)
                .setPositiveButton("Сохранить", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        String n = et.getText().toString().trim();
                        if (n.length() > 24) n = n.substring(0, 24);
                        if (n.isEmpty()) return;
                        if (VoicePreset.isBuiltinName(n) || n.equals(Store.CUSTOM_NAME)) {
                            Toast.makeText(c, "Это имя занято", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        VoiceParams p = store.getParams();
                        store.saveCustom(n, p);
                        store.setVoice(n, p);
                    }
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void confirmDelete(final String name) {
        new AlertDialog.Builder(getContext())
                .setTitle("Удалить голос «" + name + "»?")
                .setPositiveButton("Удалить", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        store.deleteCustom(name);
                    }
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    // ---------------------------------------------------------------- ползунок

    private final class Slider {
        private final TextView valueView;
        private final SeekBar bar;
        private final float min, max;
        private final int kind; // 0 полутоны, 1 проценты, 2 множитель, 3 проценты со знаком

        Slider(LinearLayout parent, String label, float min, float max, int kind) {
            Context c = getContext();
            this.min = min;
            this.max = max;
            this.kind = kind;

            LinearLayout row = new LinearLayout(c);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView l = Ui.text(c, label, 13, Ui.TEXT, false);
            valueView = Ui.text(c, "", 13, Ui.ACCENT, true);
            row.addView(l, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
            row.addView(valueView);
            LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(
                    LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
            rl.topMargin = Ui.dp(c, 6);
            parent.addView(row, rl);

            bar = new SeekBar(c);
            bar.setMax(1000);
            bar.setProgressTintList(ColorStateList.valueOf(Ui.ACCENT));
            bar.setThumbTintList(ColorStateList.valueOf(Ui.ACCENT));
            bar.setProgressBackgroundTintList(ColorStateList.valueOf(0x55FFFFFF));
            bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                    refreshLabel();
                    if (fromUser && !updating) onSliderChanged();
                }
                @Override public void onStartTrackingTouch(SeekBar sb) {}
                @Override public void onStopTrackingTouch(SeekBar sb) {}
            });
            parent.addView(bar, new LinearLayout.LayoutParams(
                    LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        }

        float value() {
            float v = min + (max - min) * bar.getProgress() / 1000f;
            if (kind == 0) v = Math.round(v * 2f) / 2f;
            return v;
        }

        void set(float v) {
            bar.setProgress(Math.round((v - min) / (max - min) * 1000f));
            refreshLabel();
        }

        private void refreshLabel() {
            float v = value();
            String s;
            switch (kind) {
                case 0: s = String.format(Locale.US, "%+.1f", v); break;
                case 2: s = String.format(Locale.US, "×%.1f", v); break;
                case 3: s = String.format(Locale.US, "%+d%%", Math.round(v * 100f)); break;
                default: s = Math.round(v * 100f) + "%"; break;
            }
            valueView.setText(s);
        }
    }
}
