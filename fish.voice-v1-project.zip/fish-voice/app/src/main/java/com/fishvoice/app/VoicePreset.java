package com.fishvoice.app;

import com.fishvoice.app.dsp.VoiceParams;

import java.util.ArrayList;
import java.util.List;

public final class VoicePreset {
    public final String name;
    public final String emoji;
    public final VoiceParams params;

    public VoicePreset(String name, String emoji, VoiceParams params) {
        this.name = name;
        this.emoji = emoji;
        this.params = params;
    }

    private static List<VoicePreset> cache;

    //                                      тон   тембр  робот  эхо   искаж. громк.
    public static synchronized List<VoicePreset> builtins() {
        if (cache == null) {
            List<VoicePreset> l = new ArrayList<VoicePreset>();
            l.add(new VoicePreset("Оригинал", "🎙", VoiceParams.neutral()));
            l.add(new VoicePreset("Мужской", "🧔", new VoiceParams(-4f, -0.35f, 0, 0, 0, 1f)));
            l.add(new VoicePreset("Женский", "👩", new VoiceParams(4f, 0.35f, 0, 0, 0, 1f)));
            l.add(new VoicePreset("Ребёнок", "🧒", new VoiceParams(8f, 0.5f, 0, 0, 0, 1f)));
            l.add(new VoicePreset("Великан", "🦍", new VoiceParams(-8f, -0.6f, 0, 0, 0, 1.1f)));
            l.add(new VoicePreset("Робот", "🤖", new VoiceParams(0f, 0.2f, 0.9f, 0, 0, 1f)));
            l.add(new VoicePreset("Пришелец", "👽", new VoiceParams(5f, 0.2f, 0.5f, 0.2f, 0, 1f)));
            l.add(new VoicePreset("Монстр", "👹", new VoiceParams(-9f, -0.5f, 0, 0, 0.35f, 1f)));
            l.add(new VoicePreset("Рация", "📻", new VoiceParams(0f, 0.5f, 0, 0, 0.45f, 1f)));
            l.add(new VoicePreset("Пещера", "🏔", new VoiceParams(-1f, -0.2f, 0, 0.75f, 0, 1f)));
            l.add(new VoicePreset("Рыбка", "🐟", new VoiceParams(3f, 0.3f, 0.2f, 0.25f, 0, 1f)));
            cache = l;
        }
        return cache;
    }

    public static boolean isBuiltinName(String n) {
        for (VoicePreset p : builtins()) if (p.name.equalsIgnoreCase(n)) return true;
        return false;
    }
}
