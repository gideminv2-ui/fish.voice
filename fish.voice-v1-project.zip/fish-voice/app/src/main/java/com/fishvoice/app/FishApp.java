package com.fishvoice.app;

import android.app.Application;

public class FishApp extends Application {
    /** LSPosed подменяет результат на true, когда модуль активен. */
    public static boolean isModuleActive() {
        return false;
    }
}
