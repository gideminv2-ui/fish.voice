package com.fishvoice.app.dsp;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Обработка потока PCM (16 бит или float, любое число каналов) на месте. */
public final class StreamProcessor {
    public static final int ENC_PCM_16 = 2;   // AudioFormat.ENCODING_PCM_16BIT
    public static final int ENC_PCM_FLOAT = 4; // AudioFormat.ENCODING_PCM_FLOAT

    private final VoiceEngine[] engines;
    private final int channels;
    private float[] work = new float[0];
    private float[] mono = new float[0];

    public StreamProcessor(int sampleRate, int channelCount) {
        channels = Math.max(1, channelCount);
        engines = new VoiceEngine[channels];
        for (int i = 0; i < channels; i++) engines[i] = new VoiceEngine(sampleRate);
    }

    private static short toShort(float v) {
        int r = Math.round(v * 32767f);
        if (r > 32767) r = 32767;
        else if (r < -32768) r = -32768;
        return (short) r;
    }

    private void run(float[] data, int n, VoiceParams p) {
        if (channels == 1) {
            engines[0].process(data, 0, n, p);
            return;
        }
        int frames = n / channels;
        if (mono.length < frames) mono = new float[frames];
        for (int c = 0; c < channels; c++) {
            for (int f = 0; f < frames; f++) mono[f] = data[f * channels + c];
            engines[c].process(mono, 0, frames, p);
            for (int f = 0; f < frames; f++) data[f * channels + c] = mono[f];
        }
    }

    private void ensure(int n) {
        if (work.length < n) work = new float[n];
    }

    public void shorts(short[] a, int off, int n, VoiceParams p) {
        ensure(n);
        for (int i = 0; i < n; i++) work[i] = a[off + i] / 32768f;
        run(work, n, p);
        for (int i = 0; i < n; i++) a[off + i] = toShort(work[i]);
    }

    public void floats(float[] a, int off, int n, VoiceParams p) {
        ensure(n);
        System.arraycopy(a, off, work, 0, n);
        run(work, n, p);
        System.arraycopy(work, 0, a, off, n);
    }

    public void bytes(byte[] a, int off, int nBytes, int encoding, VoiceParams p) {
        if (encoding == ENC_PCM_16) {
            int n = nBytes / 2;
            ensure(n);
            for (int i = 0; i < n; i++) {
                int lo = a[off + 2 * i] & 0xFF;
                int hi = a[off + 2 * i + 1];
                work[i] = (short) (lo | (hi << 8)) / 32768f;
            }
            run(work, n, p);
            for (int i = 0; i < n; i++) {
                short v = toShort(work[i]);
                a[off + 2 * i] = (byte) (v & 0xFF);
                a[off + 2 * i + 1] = (byte) ((v >> 8) & 0xFF);
            }
        } else if (encoding == ENC_PCM_FLOAT) {
            int n = nBytes / 4;
            ensure(n);
            ByteBuffer bb = ByteBuffer.wrap(a).order(ByteOrder.LITTLE_ENDIAN);
            for (int i = 0; i < n; i++) work[i] = bb.getFloat(off + 4 * i);
            run(work, n, p);
            for (int i = 0; i < n; i++) bb.putFloat(off + 4 * i, work[i]);
        }
    }

    /** Данные AudioRecord.read(ByteBuffer) пишутся с начала буфера. */
    public void buffer(ByteBuffer b, int nBytes, int encoding, VoiceParams p) {
        ByteBuffer d = b.duplicate().order(ByteOrder.LITTLE_ENDIAN);
        if (encoding == ENC_PCM_16) {
            int n = nBytes / 2;
            ensure(n);
            for (int i = 0; i < n; i++) work[i] = d.getShort(2 * i) / 32768f;
            run(work, n, p);
            for (int i = 0; i < n; i++) d.putShort(2 * i, toShort(work[i]));
        } else if (encoding == ENC_PCM_FLOAT) {
            int n = nBytes / 4;
            ensure(n);
            for (int i = 0; i < n; i++) work[i] = d.getFloat(4 * i);
            run(work, n, p);
            for (int i = 0; i < n; i++) d.putFloat(4 * i, work[i]);
        }
    }
}
