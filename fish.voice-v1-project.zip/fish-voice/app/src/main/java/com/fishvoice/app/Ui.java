package com.fishvoice.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.util.TypedValue;
import android.widget.TextView;

final class Ui {
    static final int BG1 = 0xFF071325;
    static final int BG2 = 0xFF0E2A4A;
    static final int SURFACE = 0xFF132F50;
    static final int SURFACE2 = 0xFF1C4170;
    static final int STROKE = 0xFF2A5A8E;
    static final int ACCENT = 0xFF19E3C4;
    static final int ACCENT2 = 0xFF3A8DFF;
    static final int TEXT = 0xFFEAF6FF;
    static final int MUTED = 0xFF8AA6C2;
    static final int DANGER = 0xFFFF5C7A;
    static final int OK = 0xFF35E08A;

    private Ui() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable rect(Context c, int color, float rDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, rDp));
        return g;
    }

    static GradientDrawable stroked(Context c, int fill, int stroke, float strokeDp, float rDp) {
        GradientDrawable g = rect(c, fill, rDp);
        g.setStroke(Math.max(1, dp(c, strokeDp)), stroke);
        return g;
    }

    static GradientDrawable grad(Context c, int c1, int c2, GradientDrawable.Orientation o, float rDp) {
        GradientDrawable g = new GradientDrawable(o, new int[]{c1, c2});
        g.setCornerRadius(dp(c, rDp));
        return g;
    }

    /** Фон с эффектом нажатия. */
    static Drawable ripple(Context c, Drawable content, float rDp) {
        return new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), content, rect(c, Color.WHITE, rDp));
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }
}
