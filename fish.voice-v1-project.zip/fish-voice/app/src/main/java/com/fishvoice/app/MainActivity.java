package com.fishvoice.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.Toast;

/**
 * Главное окно. Размер можно менять в любой момент: приложение поддерживает
 * многооконный режим, свободные окна и режим рабочего стола, а содержимое
 * перестраивается под любой размер.
 */
public class MainActivity extends Activity implements PanelView.Host {
    private static final int REQ_MIC = 7;
    private PanelView panel;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG1);
        getWindow().setNavigationBarColor(Ui.BG1);

        FrameLayout root = new FrameLayout(this);
        root.setBackground(Ui.grad(this, Ui.BG1, Ui.BG2, GradientDrawable.Orientation.TOP_BOTTOM, 0));

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        panel = new PanelView(this, false);
        panel.setHost(this);
        int pad = Ui.dp(this, 18);
        panel.setPadding(pad, pad, pad, pad);
        sv.addView(panel, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(sv, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c); // размер окна изменился: раскладка перестроится сама
    }

    @Override
    protected void onStop() {
        MonitorEngine.stop();
        panel.refreshMonitorButton();
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        panel.refreshMonitorButton();
    }

    // ---- PanelView.Host

    @Override
    public void openOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разреши показ поверх других окон и нажми кнопку ещё раз",
                    Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        startService(new Intent(this, OverlayService.class));
        moveTaskToBack(true);
    }

    @Override
    public void toggleMonitor() {
        if (MonitorEngine.isRunning()) {
            MonitorEngine.stop();
            panel.refreshMonitorButton();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        startMonitor();
    }

    private void startMonitor() {
        if (!MonitorEngine.start(this)) {
            Toast.makeText(this, "Не удалось открыть микрофон", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Используй наушники, иначе будет свист", Toast.LENGTH_SHORT).show();
        }
        panel.refreshMonitorButton();
    }

    @Override
    public boolean isMonitoring() { return MonitorEngine.isRunning(); }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_MIC && res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) startMonitor();
    }
}
