package com.fishvoice.app;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;

import com.fishvoice.app.dsp.StreamProcessor;

/** Прослушивание: микрофон -> эффект -> наушники. Чтобы подобрать голос. */
final class MonitorEngine {
    private static Thread thread;
    private static volatile boolean run;

    private MonitorEngine() {}

    static synchronized boolean isRunning() { return thread != null; }

    static synchronized boolean start(Context ctx) {
        if (thread != null) return true;
        final Store store = Store.get(ctx);
        final int rate = 44100;
        int minIn = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        int minOut = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (minIn <= 0 || minOut <= 0) return false;

        final AudioRecord rec;
        try {
            rec = new AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(minIn, 2048) * 2);
        } catch (Throwable t) {
            return false;
        }
        if (rec.getState() != AudioRecord.STATE_INITIALIZED) {
            rec.release();
            return false;
        }
        final AudioTrack track;
        try {
            track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(Math.max(minOut, 2048))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                    .build();
        } catch (Throwable t) {
            rec.release();
            return false;
        }

        run = true;
        thread = new Thread(new Runnable() {
            @Override public void run() {
                StreamProcessor sp = new StreamProcessor(rate, 1);
                short[] buf = new short[512];
                try {
                    rec.startRecording();
                    track.play();
                    while (run) {
                        int n = rec.read(buf, 0, buf.length);
                        if (n < 0) break;
                        if (n == 0) continue;
                        sp.shorts(buf, 0, n, store.getParams());
                        track.write(buf, 0, n);
                    }
                } catch (Throwable ignored) {
                } finally {
                    try { rec.stop(); } catch (Throwable ignored) {}
                    rec.release();
                    try { track.stop(); } catch (Throwable ignored) {}
                    track.release();
                    synchronized (MonitorEngine.class) { thread = null; }
                }
            }
        }, "fish-monitor");
        thread.start();
        return true;
    }

    static void stop() {
        Thread t;
        synchronized (MonitorEngine.class) { t = thread; }
        run = false;
        if (t != null) {
            try { t.join(600); } catch (InterruptedException ignored) {}
        }
    }
}
