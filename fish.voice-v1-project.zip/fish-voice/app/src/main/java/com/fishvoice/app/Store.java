package com.fishvoice.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;

import com.fishvoice.app.dsp.VoiceParams;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Все настройки. Файл читает и модуль LSPosed (внутри других приложений). */
public final class Store {
    public static final String PREFS = "fish_voice_prefs";
    public static final String CUSTOM_NAME = "Мой голос";

    private static Store inst;

    private final SharedPreferences sp;
    private final List<Runnable> listeners = new CopyOnWriteArrayList<Runnable>();
    private int customsVersion = 0;

    public static synchronized Store get(Context c) {
        if (inst == null) inst = new Store(c.getApplicationContext());
        return inst;
    }

    @SuppressLint("WorldReadableFiles")
    @SuppressWarnings("deprecation")
    private Store(Context app) {
        SharedPreferences s;
        try {
            // Работает, когда активен LSPosed: файл становится доступен другим приложениям
            s = app.getSharedPreferences(PREFS, Context.MODE_WORLD_READABLE);
        } catch (SecurityException e) {
            s = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        }
        sp = s;
    }

    public void addListener(Runnable r) { listeners.add(r); }
    public void removeListener(Runnable r) { listeners.remove(r); }
    public void fire() { for (Runnable r : listeners) r.run(); }

    public boolean isEnabled() { return sp.getBoolean(VoiceParams.K_ENABLED, false); }

    public void setEnabled(boolean v) {
        sp.edit().putBoolean(VoiceParams.K_ENABLED, v).apply();
        fire();
    }

    public VoiceParams getParams() { return VoiceParams.fromPrefs(sp); }

    public String getPreset() { return sp.getString("preset", "Оригинал"); }

    /** Записать голос и имя пресета, одно оповещение. */
    public void setVoice(String presetName, VoiceParams p) {
        SharedPreferences.Editor e = sp.edit();
        p.saveTo(e);
        e.putString("preset", presetName);
        e.apply();
        fire();
    }

    public int getInt(String k, int def) { return sp.getInt(k, def); }
    public void putInt(String k, int v) { sp.edit().putInt(k, v).apply(); }

    public int customsVersion() { return customsVersion; }

    public List<VoicePreset> getCustoms() {
        List<VoicePreset> out = new ArrayList<VoicePreset>();
        try {
            JSONArray a = new JSONArray(sp.getString("customs", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                JSONArray p = o.getJSONArray("p");
                out.add(new VoicePreset(o.getString("n"), "⭐", new VoiceParams(
                        (float) p.getDouble(0), (float) p.getDouble(1), (float) p.getDouble(2),
                        (float) p.getDouble(3), (float) p.getDouble(4), (float) p.getDouble(5))));
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private void writeCustoms(List<VoicePreset> l) {
        try {
            JSONArray a = new JSONArray();
            for (VoicePreset v : l) {
                JSONObject o = new JSONObject();
                o.put("n", v.name);
                JSONArray p = new JSONArray();
                p.put(v.params.pitch).put(v.params.timbre).put(v.params.robot)
                        .put(v.params.echo).put(v.params.distortion).put(v.params.gain);
                o.put("p", p);
                a.put(o);
            }
            sp.edit().putString("customs", a.toString()).apply();
        } catch (Exception ignored) {
        }
        customsVersion++;
    }

    public void saveCustom(String name, VoiceParams p) {
        List<VoicePreset> l = getCustoms();
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i).name.equals(name)) { l.remove(i); break; }
        }
        l.add(new VoicePreset(name, "⭐", p));
        writeCustoms(l);
    }

    public void deleteCustom(String name) {
        List<VoicePreset> l = getCustoms();
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i).name.equals(name)) { l.remove(i); break; }
        }
        writeCustoms(l);
        if (name.equals(getPreset())) setVoice(CUSTOM_NAME, getParams());
        else fire();
    }
}
