package com.fishvoice.app;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Плавающее окно поверх других приложений (например, поверх звонка в Telegram).
 * Окно можно перетаскивать за шапку и менять его размер за уголок в любой момент.
 */
public class OverlayService extends Service {
    static volatile boolean running = false;

    private WindowManager wm;
    private FrameLayout root;
    private WindowManager.LayoutParams lp;
    private Store store;
    private View body;
    private TextView pill;
    private boolean collapsed;
    private int expandedH;
    private int minW, minH, maxW, maxH;

    private final Runnable storeListener = new Runnable() {
        @Override public void run() { updatePill(); }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (root == null) create();
        return START_NOT_STICKY;
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private void create() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Нет разрешения «Поверх других окон»", Toast.LENGTH_LONG).show();
            stopSelf();
            return;
        }
        final Context c = this;
        store = Store.get(this);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        minW = Ui.dp(c, 220);
        minH = Ui.dp(c, 150);
        maxW = dm.widthPixels;
        maxH = dm.heightPixels;

        int w = clamp(store.getInt("ov_w", Ui.dp(c, 320)), minW, maxW);
        int h = clamp(store.getInt("ov_h", Ui.dp(c, 480)), minH, maxH);
        lp = new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = clamp(store.getInt("ov_x", Ui.dp(c, 16)), 0, Math.max(0, maxW - Ui.dp(c, 80)));
        lp.y = clamp(store.getInt("ov_y", Ui.dp(c, 90)), 0, Math.max(0, maxH - Ui.dp(c, 80)));

        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(Ui.stroked(c, 0xF2081A30, Ui.STROKE, 1, 22));

        // ---- шапка: перетаскивание, вкл/выкл, свернуть, закрыть
        LinearLayout header = new LinearLayout(c);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(Ui.dp(c, 12), Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6));
        header.setBackground(Ui.grad(c, 0xFF14375F, 0xFF0E2A4A,
                GradientDrawable.Orientation.LEFT_RIGHT, 22));
        TextView title = Ui.text(c, "🐟 fish.voice", 14, Ui.TEXT, true);
        title.setSingleLine(true);
        header.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        pill = Ui.text(c, "", 12, Ui.BG1, true);
        pill.setPadding(Ui.dp(c, 12), Ui.dp(c, 6), Ui.dp(c, 12), Ui.dp(c, 6));
        pill.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { store.setEnabled(!store.isEnabled()); }
        });
        header.addView(pill);

        TextView min = iconButton("—");
        min.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleCollapse(); }
        });
        header.addView(min);
        TextView close = iconButton("✕");
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { stopSelf(); }
        });
        header.addView(close);
        header.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy;
            int ox, oy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX(); sy = e.getRawY(); ox = lp.x; oy = lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = clamp(ox + (int) (e.getRawX() - sx), 0, Math.max(0, maxW - Ui.dp(c, 80)));
                        lp.y = clamp(oy + (int) (e.getRawY() - sy), 0, Math.max(0, maxH - Ui.dp(c, 60)));
                        wm.updateViewLayout(root, lp);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        store.putInt("ov_x", lp.x);
                        store.putInt("ov_y", lp.y);
                        return true;
                }
                return false;
            }
        });
        card.addView(header, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // ---- тело: панель + уголок для изменения размера
        FrameLayout bodyFrame = new FrameLayout(c);
        ScrollView sv = new ScrollView(c);
        PanelView panel = new PanelView(c, true);
        int pad = Ui.dp(c, 12);
        panel.setPadding(pad, pad, pad, Ui.dp(c, 48));
        sv.addView(panel, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
        bodyFrame.addView(sv, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        TextView grip = Ui.text(c, "◢", 22, Ui.BG1, true);
        grip.setGravity(Gravity.CENTER);
        grip.setBackground(Ui.grad(c, Ui.ACCENT, Ui.ACCENT2,
                GradientDrawable.Orientation.TL_BR, 18));
        FrameLayout.LayoutParams gl = new FrameLayout.LayoutParams(Ui.dp(c, 44), Ui.dp(c, 44),
                Gravity.BOTTOM | Gravity.END);
        gl.setMargins(0, 0, Ui.dp(c, 6), Ui.dp(c, 6));
        grip.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy;
            int sw, sh;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX(); sy = e.getRawY(); sw = lp.width; sh = lp.height;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.width = clamp(sw + (int) (e.getRawX() - sx), minW, maxW);
                        lp.height = clamp(sh + (int) (e.getRawY() - sy), minH, maxH);
                        wm.updateViewLayout(root, lp);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        store.putInt("ov_w", lp.width);
                        store.putInt("ov_h", lp.height);
                        return true;
                }
                return false;
            }
        });
        bodyFrame.addView(grip, gl);
        body = bodyFrame;
        card.addView(bodyFrame, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        root = new FrameLayout(c);
        root.addView(card, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        store.addListener(storeListener);
        updatePill();
        try {
            wm.addView(root, lp);
            running = true;
        } catch (Exception ex) {
            Toast.makeText(this, "Не удалось открыть окно: " + ex.getMessage(), Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    private TextView iconButton(String s) {
        TextView t = Ui.text(this, s, 15, Ui.TEXT, true);
        t.setGravity(Gravity.CENTER);
        int p = Ui.dp(this, 9);
        t.setPadding(p + Ui.dp(this, 2), p, p + Ui.dp(this, 2), p);
        return t;
    }

    private void updatePill() {
        if (pill == null) return;
        boolean on = store.isEnabled();
        pill.setText(on ? "ВКЛ" : "ВЫКЛ");
        pill.setTextColor(on ? Ui.BG1 : Ui.TEXT);
        pill.setBackground(on ? Ui.rect(this, Ui.OK, 14) : Ui.stroked(this, 0x00000000, Ui.MUTED, 1, 14));
    }

    private void toggleCollapse() {
        collapsed = !collapsed;
        if (collapsed) {
            expandedH = lp.height;
            body.setVisibility(View.GONE);
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        } else {
            body.setVisibility(View.VISIBLE);
            lp.height = clamp(expandedH, minH, maxH);
        }
        wm.updateViewLayout(root, lp);
    }

    @Override
    public void onDestroy() {
        running = false;
        if (store != null) store.removeListener(storeListener);
        if (root != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
            root = null;
        }
        super.onDestroy();
    }
}
