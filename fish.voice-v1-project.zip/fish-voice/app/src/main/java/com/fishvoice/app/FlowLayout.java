package com.fishvoice.app;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

/** Раскладка с переносом строк: сама перестраивается при изменении размера окна. */
public class FlowLayout extends ViewGroup {
    private final int hSpace;
    private final int vSpace;

    public FlowLayout(Context c, int hSpacePx, int vSpacePx) {
        super(c);
        hSpace = hSpacePx;
        vSpace = vSpacePx;
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int mode = MeasureSpec.getMode(wSpec);
        int avail = mode == MeasureSpec.UNSPECIFIED ? 100000 : MeasureSpec.getSize(wSpec);
        int maxW = Math.max(0, avail - getPaddingLeft() - getPaddingRight());
        int x = 0, y = 0, rowH = 0, used = 0;
        for (int i = 0; i < getChildCount(); i++) {
            View ch = getChildAt(i);
            if (ch.getVisibility() == GONE) continue;
            ch.measure(MeasureSpec.makeMeasureSpec(maxW, MeasureSpec.AT_MOST),
                    MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
            int cw = ch.getMeasuredWidth();
            int chh = ch.getMeasuredHeight();
            if (x > 0 && x + cw > maxW) {
                x = 0;
                y += rowH + vSpace;
                rowH = 0;
            }
            x += cw + hSpace;
            rowH = Math.max(rowH, chh);
            used = Math.max(used, x - hSpace);
        }
        int h = y + rowH + getPaddingTop() + getPaddingBottom();
        int w = mode == MeasureSpec.EXACTLY ? MeasureSpec.getSize(wSpec)
                : used + getPaddingLeft() + getPaddingRight();
        setMeasuredDimension(w, resolveSize(h, hSpec));
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int maxW = r - l - getPaddingLeft() - getPaddingRight();
        int x = 0, y = 0, rowH = 0;
        for (int i = 0; i < getChildCount(); i++) {
            View ch = getChildAt(i);
            if (ch.getVisibility() == GONE) continue;
            int cw = ch.getMeasuredWidth();
            int chh = ch.getMeasuredHeight();
            if (x > 0 && x + cw > maxW) {
                x = 0;
                y += rowH + vSpace;
                rowH = 0;
            }
            int left = getPaddingLeft() + x;
            int top = getPaddingTop() + y;
            ch.layout(left, top, left + cw, top + chh);
            x += cw + hSpace;
            rowH = Math.max(rowH, chh);
        }
    }
}
